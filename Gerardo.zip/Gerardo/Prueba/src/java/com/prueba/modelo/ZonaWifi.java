/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.prueba.modelo;

/**
 *
 * @author integration1
 */
public class ZonaWifi {
    
    private int id;
    private String convenio;
    private String operador;
    private String departamento;
    private String municipio;
    private String nombre_zona_wifi;
    private String coordenadas;
    private String direccion;
    private String total_apps;
    private String capacidad_usuarios;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the convenio
     */
    public String getConvenio() {
        return convenio;
    }

    /**
     * @param convenio the convenio to set
     */
    public void setConvenio(String convenio) {
        this.convenio = convenio;
    }

    /**
     * @return the operador
     */
    public String getOperador() {
        return operador;
    }

    /**
     * @param operador the operador to set
     */
    public void setOperador(String operador) {
        this.operador = operador;
    }

    /**
     * @return the departamento
     */
    public String getDepartamento() {
        return departamento;
    }

    /**
     * @param departamento the departamento to set
     */
    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    /**
     * @return the municipio
     */
    public String getMunicipio() {
        return municipio;
    }

    /**
     * @param municipio the municipio to set
     */
    public void setMunicipio(String municipio) {
        this.municipio = municipio;
    }

    /**
     * @return the nombre_zona_wifi
     */
    public String getNombre_zona_wifi() {
        return nombre_zona_wifi;
    }

    /**
     * @param nombre_zona_wifi the nombre_zona_wifi to set
     */
    public void setNombre_zona_wifi(String nombre_zona_wifi) {
        this.nombre_zona_wifi = nombre_zona_wifi;
    }

    /**
     * @return the coordenadas
     */
    public String getCoordenadas() {
        return coordenadas;
    }

    /**
     * @param coordenadas the coordenadas to set
     */
    public void setCoordenadas(String coordenadas) {
        this.coordenadas = coordenadas;
    }

    /**
     * @return the direccion
     */
    public String getDireccion() {
        return direccion;
    }

    /**
     * @param direccion the direccion to set
     */
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    /**
     * @return the total_apps
     */
    public String getTotal_apps() {
        return total_apps;
    }

    /**
     * @param total_apps the total_apps to set
     */
    public void setTotal_apps(String total_apps) {
        this.total_apps = total_apps;
    }

    /**
     * @return the capacidad_usuarios
     */
    public String getCapacidad_usuarios() {
        return capacidad_usuarios;
    }

    /**
     * @param capacidad_usuarios the capacidad_usuarios to set
     */
    public void setCapacidad_usuarios(String capacidad_usuarios) {
        this.capacidad_usuarios = capacidad_usuarios;
    }
    
    
}
