/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.prueba.controlador;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.prueba.conexiones.Conexion;
import com.prueba.modelo.ZonaWifi;

/**
 *
 * @author integration1
 */
public class ZonasWifiPereira extends Conexion{
    
    boolean retorno = false;

    public boolean guardarZonaWifi( ZonaWifi zonaWifi){
        String sql = "INSERT INTO ZONAS_WIF_PEREIRA(ID, "
                + "CONVENIO, "
                + "OPERADOR, "
                + "DEPARTAMENTO, "
                + "MUNICIPIO, "
                + "NOMBRE_ZONA_WIFI, "
                + "COORDENADAS, "
                + "DIRECCION, "
                + "TOTAL_APPS, "
                + "CAPACIDAD_USUASRIOS)VALUES(" 
                + zonaWifi.getConvenio() + ","
                + zonaWifi.getOperador()+ ","
                + zonaWifi.getDepartamento()+ ","
                + zonaWifi.getMunicipio()+ ","
                + zonaWifi.getNombre_zona_wifi()+ ","
                + zonaWifi.getCoordenadas()+ ","
                + zonaWifi.getDireccion()+ ","
                + zonaWifi.getTotal_apps()+ ","
                + zonaWifi.getCapacidad_usuarios()+ ")";
        
        
        try {
            
            Connection conexion = obtener();
            
            PreparedStatement preparedStatement;
            
            preparedStatement = (PreparedStatement) conexion.prepareStatement(sql);
            
            conexion.close();
            retorno = true;
            
        } catch (Exception e) {
        }
        
        
        
        return retorno;
    }
    
    
         
    
}
