/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.prueba.controlador;

import com.prueba.modelo.ZonaWifi;

/**
 *
 * @author integration1
 */
public class main {
    
    
      
  
  
  public static void main(String[] args) {
        System.out.println("prueba");
        
        ZonasWifiPereira prueba = new ZonasWifiPereira();
        ZonaWifi modelo = new ZonaWifi();
        
        modelo.setId(100);
        modelo.setConvenio("prueba");
        modelo.setOperador("prueba");
        modelo.setDepartamento("prueba");   
        modelo.setMunicipio("prueba");
        modelo.setNombre_zona_wifi("prueba");
        modelo.setCoordenadas("prueba");
        modelo.setDireccion("prueba");
        modelo.setTotal_apps("prueba");
        modelo.setCapacidad_usuarios("prueba");
        
        
        
        
        System.out.println(prueba.guardarZonaWifi(modelo));
        
        
    }
  

    
}
